### 5 Gym与Baselines

* 5-1.py：Gym基本使用方法

* snake.py：基于Gym的蛇棋环境实现

  ​