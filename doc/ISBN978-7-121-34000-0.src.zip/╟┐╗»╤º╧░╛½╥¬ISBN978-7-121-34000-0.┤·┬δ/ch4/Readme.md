### 4 Tensorflow入门

* 4-1.py：Tensorflow基本使用
* 4-2-1.py：Variable scope实验
* 4-2-2.py：创建变量实验
* 4-2-3.py：创建op实验
* 4-2-4.py：反向计算实验
* 4-2-5.py：优化实验
* 4-2-6.py：反向传播内部修改实验
* 4-2-7.py：arg_scope实验
* 4-4-1.py：MLP实验
* 4-4-2.py：CNN实验
* 4-4-3.py：RNN实验